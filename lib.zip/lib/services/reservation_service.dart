// Em lib/services/reservation_service.dart

import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ReservationService {
  // ATENÇÃO: Lembre-se de usar o IP da sua máquina, não 'localhost'
  final String _baseUrl =
      'https://vamos-comemorar-api.onrender.com/api'; // Troque pelo seu IP
  final Dio _dio = Dio();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  // Helper para configurar os headers com o token JWT
  Future<Options> _getAuthHeaders() async {
    final token = await _storage.read(key: 'jwt_token');
    if (token == null) {
      throw Exception('Usuário não autenticado.');
    }
    return Options(headers: {
      'Authorization': 'Bearer $token',
      'Content-Type': 'application/json',
    });
  }

  /// **ETAPA 2 DO ROADMAP**
  /// Cria uma reserva completa, com convidados e brindes.
  /// Mapeia para: POST /api/reservas
  Future<Map<String, dynamic>> createReservation(
      Map<String, dynamic> reservationData) async {
    try {
      final response = await _dio.post(
        '$_baseUrl/reservas',
        data: reservationData,
        options: await _getAuthHeaders(),
      );
      return response.data; // Retorna {"message": "...", "reservaId": ...}
    } on DioException catch (e) {
      print('Erro ao criar reserva: ${e.response?.data}');
      throw Exception('Falha ao criar reserva');
    }
  }

  /// **ETAPA 3 DO ROADMAP**
  /// Busca os detalhes completos de uma reserva, incluindo convidados e brindes.
  /// Mapeia para: GET /api/reservas/:id
  Future<Map<String, dynamic>> getReservationDetails(int reservaId) async {
    try {
      final response = await _dio.get(
        '$_baseUrl/reservas/$reservaId',
        options: await _getAuthHeaders(),
      );
      return response.data;
    } on DioException catch (e) {
      print('Erro ao buscar detalhes da reserva: ${e.response?.data}');
      throw Exception('Falha ao buscar detalhes da reserva');
    }
  }

  /// Busca todas as reservas criadas por um usuário específico.
  /// Mapeia para: GET /api/users/:id/reservas
  Future<List<dynamic>> getMyReservations(int userId) async {
    try {
      final response = await _dio.get(
        '$_baseUrl/users/$userId/reservas',
        options: await _getAuthHeaders(),
      );
      return response.data; // Retorna uma lista de reservas
    } on DioException catch (e) {
      print('Erro ao buscar minhas reservas: ${e.response?.data}');
      throw Exception('Falha ao buscar minhas reservas');
    }
  }

  /// Deleta um convidado específico de uma lista.
  /// Mapeia para: DELETE /api/convidados/:id
  Future<void> deleteGuest(int guestId) async {
    try {
      await _dio.delete(
        '$_baseUrl/convidados/$guestId',
        options: await _getAuthHeaders(),
      );
    } on DioException catch (e) {
      print('Erro ao deletar convidado: ${e.response?.data}');
      throw Exception('Falha ao deletar convidado');
    }
  }

  /// Atualiza o nome de um convidado específico.
  /// Mapeia para: PUT /api/convidados/:id
  Future<void> updateGuest(int guestId, String newName) async {
    try {
      await _dio.put(
        '$_baseUrl/convidados/$guestId',
        data: {'nome': newName},
        options: await _getAuthHeaders(),
      );
    } on DioException catch (e) {
      print('Erro ao atualizar convidado: ${e.response?.data}');
      throw Exception('Falha ao atualizar convidado');
    }
  }
}
